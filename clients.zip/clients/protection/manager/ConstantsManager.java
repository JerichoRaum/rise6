package com.alan.clients.protection.manager;

import lombok.Getter;

/**
 * @author Alan
 * @since 3/03/2022
 */
// Using methods to get the string because it's faster
@Getter
public class ConstantsManager {
    public String multiplayerButtonString;


}