package com.alan.clients.protection.check.api;

/**
 * @author Strikeless
 * @since 25.03.2022
 */
public enum McqBFVadWB {
    INITIALIZE,
    REPETITIVE,
    POST_INITIALIZE,
    JOIN
}
