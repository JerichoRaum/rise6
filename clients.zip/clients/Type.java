package com.alan.clients;

public enum Type {
    RISE,
    CLOVER,
    BOTH
}
