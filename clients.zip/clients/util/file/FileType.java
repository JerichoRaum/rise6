package com.alan.clients.util.file;

/**
 * @author Patrick
 * @since 10/19/2021
 */
public enum FileType {
    ACCOUNT, CONFIG, INSULT, SCRIPT
}
