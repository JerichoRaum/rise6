package com.alan.clients.component;

import com.alan.clients.util.interfaces.InstanceAccess;

public abstract class Component implements InstanceAccess {
}
