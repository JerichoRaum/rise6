package com.alan.clients.network.handler;

import packet.handler.impl.IServerPacketHandler;
import packet.impl.server.community.ServerCommunityMessageSend;
import packet.impl.server.community.ServerCommunityPopulatePacket;
import packet.impl.server.general.ServerKeepAlive;
import packet.impl.server.login.ServerLoginPacket;
import packet.impl.server.protection.ServerConstantResult;
import packet.impl.server.protection.lIllIIlllIIIIlIllIIIIllIlllllIll;
import packet.impl.server.protection.lIllIlIlIlIIIlllIIIlllIIIIlllI;
import packet.impl.server.store.IllIIIllllIlIlIIIllIlIllllIIllll;

public final class ServerPacketHandler implements IServerPacketHandler {
    @Override
    public void handle(ServerLoginPacket packet) {

    }

    @Override
    public void handle(ServerCommunityPopulatePacket packet) {

    }

    @Override
    public void handle(ServerCommunityMessageSend packet) {

    }

    @Override
    public void handle(lIllIlIlIlIIIlllIIIlllIIIIlllI packet) {

    }

    @Override
    public void handle(IllIIIllllIlIlIIIllIlIllllIIllll packet) {

    }

    @Override
    public void handle(lIllIIlllIIIIlIllIIIIllIlllllIll packet) {

    }

    @Override
    public void handle(ServerKeepAlive packet) {

    }

    @Override
    public void handle(ServerConstantResult serverConstantResult) {

    }
}
