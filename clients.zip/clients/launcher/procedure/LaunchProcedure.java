package com.alan.clients.launcher.procedure;

public interface LaunchProcedure {
    void launch();
}
