package com.alan.clients.newevent.impl.other;


import com.alan.clients.newevent.Event;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class TickEvent implements Event {

}
