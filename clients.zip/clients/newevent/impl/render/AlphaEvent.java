package com.alan.clients.newevent.impl.render;


import com.alan.clients.newevent.Event;

public class AlphaEvent implements Event {

}
