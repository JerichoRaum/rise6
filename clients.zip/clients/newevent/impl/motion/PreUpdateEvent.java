package com.alan.clients.newevent.impl.motion;

import com.alan.clients.newevent.Event;


/**
 * @author Patrick
 * @since 11/17/2021
 */
public class PreUpdateEvent implements Event {

}
