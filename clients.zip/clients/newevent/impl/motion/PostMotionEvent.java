package com.alan.clients.newevent.impl.motion;

import com.alan.clients.newevent.Event;

public final class PostMotionEvent implements Event {

}
